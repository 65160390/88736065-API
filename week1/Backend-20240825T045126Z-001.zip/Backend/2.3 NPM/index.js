// // var generateName = require('sillyname');

import generateName from "sillyName";
var sillyName = generateName();

console.log(`My name is ${sillyName}.`);

// import superheroes from "superheroes";

// const name 